package kr.ac.kopo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LocalfoodApplication {

	public static void main(String[] args) {
		SpringApplication.run(LocalfoodApplication.class, args);
	}

}
