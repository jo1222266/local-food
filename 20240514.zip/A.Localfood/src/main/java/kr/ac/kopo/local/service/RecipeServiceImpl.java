package kr.ac.kopo.local.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.ac.kopo.local.dao.RecipeDao;
import kr.ac.kopo.local.model.Recipe;

@Service
public class RecipeServiceImpl implements RecipeService {

	@Autowired
	RecipeDao dao;
	
	@Override
	public List<Recipe> list() {
		return dao.list();
	}

	@Override
	public void add(Recipe item) {
		dao.add(item);
	}

	@Override
	public Recipe item(Long roundkey) {
		return dao.item(roundkey);
	}

	@Override
	public void update(Recipe item) {
		dao.update(item);
	}

	@Override
	public void delete(Long roundkey) {
		dao.delete(roundkey);
	}

}
