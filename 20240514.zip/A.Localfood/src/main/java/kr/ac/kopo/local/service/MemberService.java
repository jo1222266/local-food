package kr.ac.kopo.local.service;

import java.util.List;

import kr.ac.kopo.local.model.Member;

public interface MemberService {

	List<Member> list();

	void add(Member item);

	Member item(String id);

	void update(Member item);

	void delete(String id);

}
