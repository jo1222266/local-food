package kr.ac.kopo.local.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

public class Member implements UserDetails{
	private static final long serialVersionUID = 1L;
	private String id;
	private String passwd;
	private String name;
	private String nickname;
	private String mail;
	private Long role;
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public String getPasswd() {
		return passwd;
	}
	
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getNickname() {
		return nickname;
	}
	
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	
	public String getMail() {
		return mail;
	}
	
	public void setMail(String mail) {
		this.mail = mail;
	}
	
	public Long getRole() {
		return role;
	}
	
	public void setRole(Long role) {
		this.role = role;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		List<SimpleGrantedAuthority> list = new ArrayList<>();
		
		if(id.equals("admin")) {
			list.add(new SimpleGrantedAuthority("ROLE_MEMBER"));
			list.add(new SimpleGrantedAuthority("ROLE_CLASS"));
			list.add(new SimpleGrantedAuthority("ROLE_RECIPE"));
		}else if(id.equals("user")) {
			list.add(new SimpleGrantedAuthority("ROLE_CLASS"));
			list.add(new SimpleGrantedAuthority("ROLE_RECIPE"));
		}else {
			list.add(new SimpleGrantedAuthority("ROLE_RECIPE"));
		}
		
		return list;
	}

	@Override
	public String getPassword() {
		return passwd;
	}

	@Override
	public String getUsername() {
		return id;
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}
	
}
