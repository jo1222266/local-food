package kr.ac.kopo.local.service;

import java.util.List;

import kr.ac.kopo.local.model.Recipe;

public interface RecipeService {

	List<Recipe> list();

	void add(Recipe item);

	Recipe item(Long roundkey);

	void update(Recipe item);

	void delete(Long roundkey);

}
