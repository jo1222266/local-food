package kr.ac.kopo.local.model;

public class Recipe {
	private Long roundkey;
	private String id;
	private String subject;
	private String nickname;
	private String text;

	public Long getRoundkey() {
		return roundkey;
	}

	public void setRoundkey(Long roundkey) {
		this.roundkey = roundkey;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
}
