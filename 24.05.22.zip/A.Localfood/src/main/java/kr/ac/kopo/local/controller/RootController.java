package kr.ac.kopo.local.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import kr.ac.kopo.local.model.Member;
import kr.ac.kopo.local.service.MemberService;

@Controller
public class RootController {
	
	@Autowired
	MemberService service;
	
	@GetMapping("/")
	public String index(@AuthenticationPrincipal Member member, Model model) {
		if(member != null) {
			model.addAttribute("member", member);
			
			List<Member> list = service.list();
			
			model.addAttribute("list", list);
			
			Member item = service.item(member.getId());
			
			model.addAttribute("item", item);
		}
		
		
		return "index";
	}
	
	@GetMapping("/login")
	public String login() {
		
		return "login";
	}
}
