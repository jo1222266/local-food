package kr.ac.kopo.local.controller;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import kr.ac.kopo.local.model.Member;

@Controller
public class RootController {
	@GetMapping("/")
	public String index(@AuthenticationPrincipal Member member, Model model) {
		if(member != null) {
			model.addAttribute("member", member);
			
		}
		
		return "index";
	}
	
	@GetMapping("/login")
	public String login() {
		
		return "login";
	}
}
