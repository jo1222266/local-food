package kr.ac.kopo.local.dao;

import java.util.List;

import kr.ac.kopo.local.model.Member;

public interface MemberDao {

	List<Member> list();

	void add(Member item);

	Member item(String id);

	void update(Member item);

	void delete(String id);

	//int total(pager);

}
