package kr.ac.kopo.local.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import kr.ac.kopo.local.dao.MemberDao;
import kr.ac.kopo.local.model.Member;

@Service
public class MemberServiceImpl implements MemberService {

	@Autowired
	MemberDao dao;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Override
	public List<Member> list() {
		//int total = dao.total(pager);
		
		//pager.setTotal(total);
		
		return dao.list();
	}

	@Override
	public void add(Member item) {
		item.setPasswd(passwordEncoder.encode(item.getPasswd()));
		dao.add(item);
	}

	@Override
	public Member item(String id) {
		return dao.item(id);
	}

	@Override
	public void update(Member item) {
		item.setPasswd(passwordEncoder.encode(item.getPasswd()));
		dao.update(item);
	}

	@Override
	public void delete(String id) {
		dao.delete(id);
	}

}
