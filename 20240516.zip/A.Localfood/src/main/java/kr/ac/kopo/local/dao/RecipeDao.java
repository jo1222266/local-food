package kr.ac.kopo.local.dao;

import java.util.List;

import kr.ac.kopo.local.model.Recipe;

public interface RecipeDao {

	List<Recipe> list();

	void add(Recipe item);

	Recipe item(Long roundkey);

	void update(Recipe item);

	void delete(Long roundkey);

}
